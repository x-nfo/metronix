<script setup>
defineProps({
    type: String,
});
</script>
<template>
    <div class="pt-20 pb-2">
        <svg
            v-if="type == 'login'"
            width="256"
            height="100"
            viewBox="0 0 56 40"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                d="M43.6528 1.98347L54.516 35.8074C55.1083 37.6516 53.7327 39.5382 51.7958 39.5382H43.8076C42.5628 39.5382 41.4612 38.7322 41.0845 37.5458L30.3448 3.7218C29.7598 1.87944 31.1349 0 33.0679 0H40.9325C42.1739 0 43.2733 0.801564 43.6528 1.98347Z"
                fill="#EF305E"
            />
            <g filter="url(#filter0_i_8605_3258)">
                <path
                    d="M33.249 27L25.5888 2.46371C25.1313 0.998064 23.7741 0 22.2387 0C20.3698 0 18.8288 1.46454 18.7336 3.33101L17.7991 21.6709C17.766 22.3222 17.8446 22.9745 18.0315 23.5994L22.1898 37.4999C22.5516 38.7096 23.6645 39.5382 24.9271 39.5382H28.7924C30.036 39.5382 31.1368 38.7339 31.5146 37.549L33.2334 32.1581C33.7681 30.4811 33.7735 28.6802 33.249 27Z"
                    fill="white"
                />
                <path
                    d="M33.249 27L25.5888 2.46371C25.1313 0.998064 23.7741 0 22.2387 0C20.3698 0 18.8288 1.46454 18.7336 3.33101L17.7991 21.6709C17.766 22.3222 17.8446 22.9745 18.0315 23.5994L22.1898 37.4999C22.5516 38.7096 23.6645 39.5382 24.9271 39.5382H28.7924C30.036 39.5382 31.1368 38.7339 31.5146 37.549L33.2334 32.1581C33.7681 30.4811 33.7735 28.6802 33.249 27Z"
                    fill="url(#paint0_linear_8605_3258)"
                />
            </g>
            <path
                d="M14.512 0H22.3796C24.3062 0 25.6806 1.86778 25.1074 3.70711L14.4781 37.8196C14.1061 39.0136 13.0009 39.8269 11.7503 39.8269H3.88281C1.95625 39.8269 0.581894 37.9591 1.15502 36.1197L11.7843 2.00718C12.1563 0.813257 13.2615 0 14.512 0Z"
                fill="#EF305E"
            />
            <defs>
                <filter
                    id="filter0_i_8605_3258"
                    x="13.7917"
                    y="0"
                    width="19.8467"
                    height="42.5381"
                    filterUnits="userSpaceOnUse"
                    color-interpolation-filters="sRGB"
                >
                    <feFlood flood-opacity="0" result="BackgroundImageFix" />
                    <feBlend
                        mode="normal"
                        in="SourceGraphic"
                        in2="BackgroundImageFix"
                        result="shape"
                    />
                    <feColorMatrix
                        in="SourceAlpha"
                        type="matrix"
                        values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                        result="hardAlpha"
                    />
                    <feOffset dx="-4" dy="3" />
                    <feGaussianBlur stdDeviation="2" />
                    <feComposite
                        in2="hardAlpha"
                        operator="arithmetic"
                        k2="-1"
                        k3="1"
                    />
                    <feColorMatrix
                        type="matrix"
                        values="0 0 0 0 0.904167 0 0 0 0 0.892865 0 0 0 0 0.892865 0 0 0 0.4 0"
                    />
                    <feBlend
                        mode="normal"
                        in2="shape"
                        result="effect1_innerShadow_8605_3258"
                    />
                </filter>
                <linearGradient
                    id="paint0_linear_8605_3258"
                    x1="20.7143"
                    y1="17.5"
                    x2="28.9286"
                    y2="19.6429"
                    gradientUnits="userSpaceOnUse"
                >
                    <stop stop-opacity="0.25" />
                    <stop
                        offset="0.911458"
                        stop-color="white"
                        stop-opacity="0"
                    />
                </linearGradient>
            </defs>
        </svg>
    </div>
</template>
